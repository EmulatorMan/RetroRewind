These modifications were made by ToadKing: https://github.com/ToadKing/mupen64plus-libretro-nx/tree/emscripten-support

TODO:

- gles2 support